//constructor
package com.corejava.example;

public class Example1 {

	public Example1() {
		System.out.println("Default constructor");
	}
	
	public static void main(String[] args) {
		new Example1();
	}
}
